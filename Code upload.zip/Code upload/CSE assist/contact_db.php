<?php
$insert = false;
$otp_sent= false;
$otp_verified = false;

if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Set connection variables
    $server = "localhost";
    $username = "root";
    $password = "";


    // Create a database connection
    $con = mysqli_connect($server, $username, $password); 

    $name = $_REQUEST['name'];
    $email = $_REQUEST['email'];
    $message=$_REQUEST['message'];
    // $password = $_REQUEST['password'];

    // $password=password_hash($password, PASSWORD_BCRYPT);

    // $email_exits = $con->prepare("SELECT * FROM `database`.`register` WHERE email = ?");
    // $email_exits->bind_param("s", $_POST['email']);
    // $email_exits->execute();
    // $email_exits->store_result();
    // $email_exits->fetch();
    // $n=$email_exits->num_rows;

    // if ($n==0)
    // {

        $sql = "INSERT INTO `database`.`contact` (`name`,`email`,`message`) VALUES ('$name','$email','$message')";
        
       

        if($con->query($sql) == true){
                
            // echo"Flag for successful insertion";
            // echo $n;
            // echo mysqli_num_rows($user);
            $insert = true;
            echo "Feedback recorded!";
            // header('Location: login.php');
    
        }
        else{
            echo "ERROR: $sql <br> $con->error";
        }

       

    // } else {
    //     // echo mysqli_affected_rows($email_exits);
    //     // echo $n;

    //     echo "exits already";
        
    //     // header('Location: register.php');
       
    // }

}
// else{
//     echo "not post set";
// }
?>