<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cse Assist/Contact</title>
    <link rel="stylesheet" href="style2.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <h2 class="logo"><a href="index.html">CSE Mitra</a></h2>
        <div class="secondPart">
            <ul class="main">
                <a href="index.html">
                    <li class="navigation">Home</li>
                </a>
                <a href="Domain/Domains.html">
                    <li class="navigation">Domains</li>
                </a>
                
                <a href="contact.html">
                    <li class="navigation">Contact</li>
                </a>
            </ul>
            <div class="buttons">
                <a href="http://localhost/Login%20form/login.php"><input type="button" value="Login" class="btn1"></a>
                <a href="http://localhost/Login%20form/register.php"><input type="button" value="Signup" class="btn1"></a>
            </div>
        </div>
    </nav>
    <hr>
    <div class="combined_card1">
        <div class="contact_cards1">
            <div class="intro"><p>Hello, I am Abhay, a jolly Developer. I have had an hefty role in designing the front-end of the website</p></div>
            <div class="testim1">
                <h3>Abhay Chanana</h3>
                <h4>Front-end Developer</h4>
            </div>
        </div>
        <div class="contact_cards1">
            <div class="intro"><p>Hello, Myself Akshat - front-end Developer. I have a major role designing the pages of the website</p>
            </div>  
            <div class="testim1">
                <h3>Akshat Garg</h3>
                <h4>Front-end Developer</h4>
            </div>
        </div>
    </div>
        <div class="logo_image">
        <img src="Images/Logo.png" alt="">
        </div>
    <div class="combined_card1">
        <div class="contact_cards2">
            <div class="intro"><p>Hii!. I am Priyanshu Kumar. The Backend Developer of this website. I have handed down the required code for backend connectivity.</p></div>
            <div class="testim1">
                <h3>Priyanshu Kumar</h3>
                <h4>Backend Developer</h4>
            </div>
        </div>
        <div class="contact_cards2">
            <div class="intro"><p>Hey!. I am Hemant. I have worked for database connectivity and did research for the course.</p>
            </div>
            
            <div class="testim1">
                <h3>Hemant</h3>
                <h4>Backend Developer</h4>
            </div>
        </div>
    </div>


    <section id="contact-form">
        <h2>Contact</h2>
        <form action="contact_db.php" id="contact" name="contact" accept-charset="utf-8" method="post">
          <label><span>Name</span><input name="name" type="text" placeholder="Name"/></label>
          <label><span>Email</span><input name="email" type="email" placeholder="Email"/></label>
          <label><span>Message</span><textarea name="message" placeholder="Message"></textarea></label>
          <input name="submit" type="submit" value="Send"/>
        </form>
      </section>
      <footer class="footer">
            <div class="footerimg">\
            <img src="Images/Logo.png" alt="">
            </div>
            <h3>CSE Mitra</h3>
            <p> Copyright &copy 2022;</p>
    </footer>
      <script src="contact_form.js"></script>
</body>
</html>