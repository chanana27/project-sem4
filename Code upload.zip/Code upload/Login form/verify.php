<?php

if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Set connection variables
    $server = "localhost";
    $username = "root";
    $password = "";

    $con = mysqli_connect($server, $username, $password); 

    $userEmail=$_REQUEST['email'];
    $password=$_REQUEST['password'];
    

    $stmt = $con->prepare("SELECT * FROM `database`.`register` WHERE email = ?");
    $stmt->bind_param("s", $_POST['email']);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();


    if ($user && password_verify($_POST['password'], $user['password']))
    {
        header('Location: ../CSE assist/index.html');

    } else {

        echo "Login failed";
    }


    // Close the database connection
    $con->close();

}
else{
    
    echo "server error";
}


?>