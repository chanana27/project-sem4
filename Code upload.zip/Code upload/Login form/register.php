<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CSE Assist/Login</title>
    
    <link rel="stylesheet" href="../CSE assist/login.css">
</head>
<body>
    <form action="index.php" method="post">

        <h2>Signup</h2>

        <label>Enter User Name</label>
        <input type="text" name="uname" placeholder="User Name"><br>

        <label>Create Password</label>
        <input type="password" name="password" placeholder="Password"><br> 
        
        <label>Enter Email</label>
        <input type="email" name="email" placeholder="Enter Email"><br>
        
        <label>Enter Date of Birth</label>
        <input type="date" name="DOB" placeholder="Enter DOB"><br>
        
        
        <button type="submit">Signup</button>

     </form>
</body>
</html>